"""Example replaceable policy plugins."""
