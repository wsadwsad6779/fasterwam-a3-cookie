print("put_ok")
