"""Model namespace for FasterWAM."""
