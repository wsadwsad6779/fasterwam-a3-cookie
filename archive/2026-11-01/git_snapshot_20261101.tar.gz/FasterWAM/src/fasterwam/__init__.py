"""FasterWAM package."""
