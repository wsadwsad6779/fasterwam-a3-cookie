# DATASET_800_DIVERSITY_REPORT

- parquet episodes: 845; metadata lines: 845
- exact action-duplicate groups: 0
- dims: action=8 state=8 force=18
- pad contact rate: {"L_in": 0.508795083377434, "L_out": 0.5093504247817291, "R_in": 0.0, "R_out": 0.0}
- metadata field summary: {"episode_index": 749, "seed": 845, "task": 2, "controller_type": 2, "source_action_mode": 1, "stored_action_mode": 1, "frames": 67, "success": 1, "randomization": 845, "source_shard": 16, "source_dataset": 2}
- NOT OBTAINED: camera extrinsics / lighting / friction; do not infer.
